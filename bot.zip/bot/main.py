# Copyright [2020] [commaster] Licensed under the Apache License, Version 2.0 (the «License»);
import time

print("IMPORTANT!!")
print("Soft under the Apache License, Version 2.0 (the «License»);")
print("Creator: @commaster1, https://github.com/bonsai-minter/bithumb-bot")
print()
print("Wait 3 seconds....")
time.sleep(3)
import strategy.bithumb